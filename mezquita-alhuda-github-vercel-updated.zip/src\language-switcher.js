language-switcher.js
translation-helper.js
mosque-i18n.js